#include "Executive.h"

#include <stdio.h>
#include <cstdio>
#include <wiringPi.h>
#include <wiringSerial.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>

//extern int a1;
int main(int argc, char *argv[]) //int serialOpen (const char *device, const int baud)
{
	Executive exe1;
	exe1.run();
	


	return 0;
}

